#!/bin/bash

/usr/bin/osxexe
